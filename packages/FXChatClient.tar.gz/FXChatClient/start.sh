java -jar FXChatClient.jar
