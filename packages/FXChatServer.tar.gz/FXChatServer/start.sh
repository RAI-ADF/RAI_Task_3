java -jar FXChatServer.jar
